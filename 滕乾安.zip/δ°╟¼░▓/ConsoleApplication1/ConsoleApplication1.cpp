﻿// ConsoleApplication1.cpp : 定义应用程序的入口点。
//

#include "stdafx.h"
#include "ConsoleApplication1.h"

#define Limer 1;
//响应键盘
#define L_up 1;
#define L_down 2;
#define L_left 3;
#define L_right 4;


#define Max_x 500;
#define Min_x 0;
#define May_y 650;
#define Min_y 0;

#define MAX_LOADSTRING 100

void paintcircle(HDC &hdc, int &x, int &y);//暂停画圆
void Gamemap(HDC hdc, int x1, int y1, int x2, int y2, int map[][13], int &score);//地图初始化
void Gamedraw(HDC hdc, int &x, int &y, long &k, int &dr);//嘴的绘制
void GamePlay(HWND hwnd, HDC &hdc, int &x, int &y, int map[][13]);//吃豆子的实现
void GameOver(HWND hWnd, HDC &hdc, int &x, int &y);//游戏结束
//void paintcircle(HDC &hdc, int &x, int &y);
//1代表墙壁，2代表食物，0表示空白
static int map[10][13] =
{
	{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
	{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 0, 2, 0, 2, 0, 0, 2, 0, 0, 0, 0, 1 },
	{ 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 1 },
	{ 1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 1 },
	{ 1, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
};

static int score = 0;//成绩
static int lx = 75, ly = 75, gx = 425, gy = 0;//嘴的初始位置
long panduan = 0, m = 0, n = 0;

// 全局变量: 
HINSTANCE hInst;								// 当前实例
TCHAR szTitle[MAX_LOADSTRING];					// 标题栏文本
TCHAR szWindowClass[MAX_LOADSTRING];			// 主窗口类名
int Direction = 0;//四个方向

// 此代码模块中包含的函数的前向声明: 
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPTSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO:  在此放置代码。
	MSG msg;
	HACCEL hAccelTable;

	// 初始化全局字符串
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_CONSOLEAPPLICATION1, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// 执行应用程序初始化: 
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_CONSOLEAPPLICATION1));

	// 主消息循环: 
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  函数:  MyRegisterClass()
//
//  目的:  注册窗口类。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.lpfnWndProc = WndProc;
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_CONSOLEAPPLICATION1));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)CreateSolidBrush(RGB(118, 134, 241));
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_CONSOLEAPPLICATION1);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   函数:  InitInstance(HINSTANCE, int)
//
//   目的:  保存实例句柄并创建主窗口
//
//   注释: 
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // 将实例句柄存储在全局变量中

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  函数:  WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  目的:    处理主窗口的消息。
//
//  WM_COMMAND	- 处理应用程序菜单
//  WM_PAINT	- 绘制主窗口
//  WM_DESTROY	- 发送退出消息并返回
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_TIMER:
	{
					 RECT rect;
					 rect.left = 0;
					 rect.top = 0;
					 rect.right = 650;
					 rect.bottom = 500;
					 InvalidateRect(hWnd, &rect, TRUE);//刷新窗口
	}
		break;
	case WM_CREATE:
	{
					  SetTimer(hWnd, 1, 300, NULL);
	}
		break;
	case WM_KEYDOWN:
	{
					   switch (wParam)
					   {
					   case VK_UP:
						   Direction = L_up; break;
					   case VK_DOWN:
						   Direction = L_down; break;
					   case VK_LEFT:
						   Direction = L_left; break;
					   case VK_RIGHT:
						   Direction = L_right; break;
					   case VK_SPACE:
						   SetTimer(hWnd, 1, 200, NULL); break;
					   case VK_ESCAPE:
						   KillTimer(hWnd, 1);
						   paintcircle(hdc, lx, ly);
						   break;
					   case VK_RETURN:
						   SetTimer(hWnd, 1, 300, NULL); break;
					   default:
						   return DefWindowProc(hWnd, message, wParam, lParam);
					   }
	}
		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// 分析菜单选择: 
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO:  在此添加任意绘图代码...
		SetMapMode(hdc, MM_ANISOTROPIC);
		SetWindowExtEx(hdc, 100, 110, NULL);
		SetViewportExtEx(hdc, 100, 100, NULL);
		SetViewportOrgEx(hdc, 20, 20, NULL);
		panduan++;
		Gamemap(hdc, 0, 0, 650, 550, map, score);
		Gamedraw(hdc, lx, ly, panduan, Direction);
		GamePlay(hWnd, hdc, lx, ly, map);
		GameOver(hWnd, hdc, lx, ly);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		KillTimer(hWnd, 1);
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}



void Gamemap(HDC hdc, int x1, int y1, int x2, int y2, int map[][13],int &score)
{
	for (int i = 0; i <650; i=i+50)
	{
		for (int j = 0; j <500; j = j + 50)
		{
			if (map[j / 50][i / 50] == 2)
			{
				HBRUSH hb6;
				hb6 = CreateSolidBrush(RGB(225, 225, 0));//黄色画刷
				SelectObject(hdc, hb6);
				Ellipse(hdc, i+20 , j +20, i+40 , j +40);//画豆子
				DeleteObject(hb6);
			}
			else if (map[j / 50][i/ 50] == 1)
			{
				HBRUSH hb7;
				//创建一个画刷的函数为CreateSolidBrush(COLORREF c)
				hb7 = CreateSolidBrush(RGB(218, 112, 214));//画刷
				//RGB分别代表红色，绿色和蓝色在颜色中所占的比例
				SelectObject(hdc, hb7);
				Rectangle(hdc, i, j, i+50 , j +50);//画墙
				DeleteObject(hb7);
			}
		}
	}
	HPEN hps;
	hps = CreatePen(PS_INSIDEFRAME, 3, RGB(255, 0, 0));//红色
	SelectObject(hdc, hps);
	MoveToEx(hdc, 680, 0, NULL);
	//将线“拉伸”到目的地点
	LineTo(hdc, 680, 500);
	LineTo(hdc, 900, 500);
	LineTo(hdc, 900, 0);
	LineTo(hdc, 680, 0);
	DeleteObject(hps);

	TCHAR szBuffer[100];
	//该函数用当前选择的字体、背景颜色和正文颜色将一个字符串写到指定位置
	/*BOOL TextOut(

HDC hdc, // 设备描述表句柄

int nXStart, // 字符串的开始位置 x坐标

int nYStart, // 字符串的开始位置 y坐标

LPCTSTR lpString, // 字符串

int cbString // 字符串中字符的个数

);
	*/
	TextOut(hdc, 700, 50, szBuffer, wsprintf(szBuffer, TEXT("PS:'↑'，'↓','←','→'进行控制")));
	TextOut(hdc, 700, 80, szBuffer, wsprintf(szBuffer, TEXT("PS:按下ESC键，游戏暂停")));
	TextOut(hdc, 700, 110, szBuffer, wsprintf(szBuffer, TEXT("PS:按下ENTER键，游戏开始")));
	TextOut(hdc, 700, 150, szBuffer, wsprintf(szBuffer, TEXT("游戏成绩：%d"),score));
}

//嘴的绘制
void Gamedraw(HDC hdc, int &x, int &y, long &k,int&dr)
{
	HPEN hp1;//句柄
	hp1 = CreatePen(PS_SOLID, 2, RGB(102, 205, 172));
	/*​[声明]

HPEN CreatePen(int nPenStyle, int nWidth, COLORREF crColor);

[说明]

用指定的样式、宽度和颜色创建一个画笔

[参数表]

nPenStyle ------ Long，指定画笔样式，可以是下述常数之一

PS_SOLID                 画笔画出的是实线

PS_DASH                  画笔画出的是虚线(nWidth必须不大于1)

PS_DOT                    画笔画出的是点线(nWidth必须不大于1)

PS_DASHDOT           画笔画出的是点划线(nWidth必须不大于1)

PS_DASHDOTDOT    画笔画出的是点-点-划线(nWidth必须不大于1)

PS_NULL                    画笔不能画图

PS_INSIDEFRAME    由椭圆、矩形、圆角矩形、饼图以及弦等生成的封闭对象框时，画线宽度向内扩展。

如指定的准确RGB颜 色不存在，就进行抖动处理

nWidth --------- Long，以逻辑单位表示的画笔的宽度

crColor -------- Long，画笔的RGB颜色

[返回值]

Long，如函数执行成功，就返回指向新画笔的一个句柄;否则返回零

[其它]

一旦不再需要画笔，记得用DeleteObject函数将其删除
	*/
	SelectObject(hdc, hp1);
	switch (dr)
	{
	case 0:
	{
			  Pie(hdc, x - 20, y - 20, x + 20, y + 20, x + 10, y - 10, x + 10, y + 10);
			  HPEN hp5;
			  hp5 = (HPEN)GetStockObject(WHITE_BRUSH);
			  SelectObject(hdc, hp5);//创建画笔资源函数
			  Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);//绘制椭圆
			  DeleteObject(hp5);//释放画笔资源的函数
	}
		break;
	case 1:
	{
			  if (k % 2 == 0)
			  {
				  if (y >= 75)
				  {
					  if (map[(y - 25) / 50 - 1][(x - 75) / 50 + 1] == 2 || map[(y - 25) / 50 - 1][(x - 75) / 50 + 1] == 0)
					  {
						  Pie(hdc, x - 20, y - 20, x + 20, y + 20, x - 10, y - 10, x + 10, y - 10);//向上的嘴
						  HPEN hp2;
						  hp2 = (HPEN)GetStockObject(WHITE_BRUSH);
						  SelectObject(hdc, hp2);
						  Ellipse(hdc, x - 3, y + 13, x - 13, y + 3);//眼睛
						  DeleteObject(hp2);
						  y = y - 25;
					  }
				  }
			  }
			  else
			  {
				  Ellipse(hdc, x - 20, y - 20, x + 20, y + 20);//圆
				  HPEN hp3;
				  hp3 = (HPEN)GetStockObject(WHITE_BRUSH);
				  SelectObject(hdc, hp3);
				  Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);//眼睛
				  DeleteObject(hp3);
			  }
	}
		break;
	case 2:
	{
			  if (k % 2 == 0)
			  {
				  if (y <= 475)
				  {
					  if (map[(y - 25) / 50 + 1][(x - 75) / 50 + 1] == 2 || map[(y - 25) / 50 + 1][(x - 25) / 50 + 1] == 0)
					  {
						  //pie函数画一个由椭圆和两条半径相交闭合而成的饼状楔形图，此饼图由当前画笔画轮廓，由当前画刷填充
						  Pie(hdc, x - 20, y - 20, x + 20, y + 20, x + 10, y + 10, x - 10, y + 10);
						  HPEN hp3;
						  hp3 = (HPEN)GetStockObject(WHITE_BRUSH);
						  SelectObject(hdc, hp3);
						  Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);
						  DeleteObject(hp3);
						  y = y + 25;
					  }
				  }
			  }
			  else
			  {
				  Ellipse(hdc, x - 20, y - 20, x + 20, y + 20);//圆
				  HPEN hp3;
				  hp3 = (HPEN)GetStockObject(WHITE_BRUSH);
				  SelectObject(hdc, hp3);
				  Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);//眼睛
				  DeleteObject(hp3);
			  }
	}
		break;
	case 3:
	{
			  if (k % 2 == 0)
			  {
				  if (x >= 25)
				  {
					  if (map[(y - 75) / 50 + 1][(x - 25) / 50 - 1] == 2 || map[(y - 75) / 50 + 1][(x - 25) / 50 + 1] == 0)
					  {
						  Pie(hdc, x - 20, y - 20, x + 20, y + 20, x - 10, y + 10, x - 10, y - 10);
						  HPEN hp4;
						  hp4 = (HPEN)GetStockObject(WHITE_BRUSH);
						  SelectObject(hdc, hp4);
						  Ellipse(hdc, x + 2, y - 13, x + 12, y - 3);
						  DeleteObject(hp4);
						  x = x - 25;
					  }
				  }
			  }
			  else
			  {
				  Ellipse(hdc, x - 20, y - 20, x + 20, y + 20);//圆
				  HPEN hp4;
				  hp4 = (HPEN)GetStockObject(WHITE_BRUSH);
				  SelectObject(hdc, hp4);
				  Ellipse(hdc, x + 2, y - 13, x + 12, y - 3);//眼睛
				  DeleteObject(hp4);
			  }
	}
		break;
	case 4:
	{
			  if (k % 2 == 0)
			  {
				  if (x <= 625)
				  {
					  if (map[(y - 75) / 50 + 1][(x - 25) / 50 + 1] == 2 || map[(y - 75) / 50][(x - 25) / 50 + 1] == 0)
					  {
						  Pie(hdc, x - 20, y - 20, x + 20, y + 20, x + 10, y - 10, x + 10, y + 10);
						  HPEN hp5;
						  hp5 = (HPEN)GetStockObject(WHITE_BRUSH);
						  SelectObject(hdc, hp5);
						  Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);
						  DeleteObject(hp5);
						  x = x + 25;
					  }
				  }
			  }
			  else
			  {
				  Ellipse(hdc, x - 20, y - 20, x + 20, y + 20);
				  HPEN hp5;
				  hp5 = (HPEN)GetStockObject(WHITE_BRUSH);
				  SelectObject(hdc, hp5);
				  Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);
				  DeleteObject(hp5);
			  }
	}
		break;
	}
	DeleteObject(hp1);
}

//坐标变化及豆子数组变化，自动走，消去被吃到豆子
void GamePlay(HWND hWnd, HDC &hdc, int &x, int &y, int map[][13])
{
	for (int i = 0; i < 650; i = i + 50)
	{
		for (int j = 0; j < 500; j = j + 50)
		{
			if (map[j / 50][i / 50] == 2)
			{
				m = j + 25;
				n = i + 25;
				if (y == m&&x == n)
				{
					map[j / 50][i / 50] = 0;
					RECT rect;
					rect.left = 750;
					rect.top = 100;
					rect.right = 850;
					rect.bottom = 200;
					InvalidateRect(hWnd,&rect,FALSE);
					/*该函数向指定的窗体更新区域添加一个矩形，然后窗口客户区域的这一部分将被重新绘制。

BOOL InvalidateRect(

HWND hWnd, // handle of window with changed update region

CONST RECT *lpRect, // address of rectangle coordinates

BOOL bErase // erase-background flag

);
					*/
					score = score + 10;
				}
			}
		}
	}
}

//游戏结束的判断
void GameOver(HWND hWnd, HDC &hdc, int &x, int &y)
{
	if (score == 120)
	{
		KillTimer(hWnd,1);
		if (IDYES == MessageBox(hWnd, TEXT("恭喜你吃完所有的豆子"), TEXT("GAME OVER"), MB_YESNO))
		{
			/*MessageBox显示一个模态对话框，其中包含一个系统图标、
			一组按钮和一个简短的特定于应用程序消息，如状态或错误的信息。
			消息框中返回一个整数值，该值指示用户单击了哪个按钮。
			*/
			DestroyWindow(hWnd);
			/*销毁指定的窗口。这个函数通过发送WM_DESTROY 消息和 WM_NCDESTROY 消息使窗口无效并移除其键盘焦点。
			这个函数还销毁窗口的菜单，清空线程的消息队列，销毁与窗口过程相关的定时器，
			解除窗口对剪贴板的拥有权，打断剪贴板器的查看链。　*/
			KillTimer(hWnd, 1);
			//KillTimer:移除定时器函数的声明:移除先前用SetTimer设置的定时器。在定时器使用完毕后移除定时器时使用。
		}
	}
}

void paintcircle(HDC &hdc, int &x, int &y)
{
	Ellipse(hdc, x - 20, y - 20, x + 20, y + 20);
	HPEN hp5;
	hp5 = (HPEN)GetStockObject(WHITE_BRUSH);
	SelectObject(hdc, hp5);
	Ellipse(hdc, x - 3, y - 13, x - 13, y - 3);
	DeleteObject(hp5);
}