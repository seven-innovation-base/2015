// BEANSView.cpp : implementation of the CBEANSView class
//

#include "stdafx.h"
#include "BEANS.h"

#include "BEANSDoc.h"
#include "BEANSView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

struct Beans
{
	int x,y;
	int len;
	int direct;
}Beans[50];

struct Food
{
	int x;
	int y;
	int isfood;
}Food;
/////////////////////////////////////////////////////////////////////////////
// CBEANSView

IMPLEMENT_DYNCREATE(CBEANSView, CView)

BEGIN_MESSAGE_MAP(CBEANSView, CView)
	//{{AFX_MSG_MAP(CBEANSView)
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_PAINT()
	ON_COMMAND(IDM_START, OnStart)
	ON_COMMAND(IDM_PAUSE, OnPause)
	ON_COMMAND(IDM_EXIT, OnExit)
	ON_COMMAND(IDM_CONTINUE, OnContinue)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBEANSView construction/destruction

CBEANSView::CBEANSView()
{
	// TODO: add construction code here

}

CBEANSView::~CBEANSView()
{

}

BOOL CBEANSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBEANSView drawing

void CBEANSView::OnDraw(CDC* pDC)
{
	CBEANSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CBrush backBrush(RGB(100,100,0));
	CBrush* poldBrush=pDC->SelectObject(&backBrush);
	CRect rect;
	pDC->GetClipBox(&rect);
	pDC->PatBlt(rect.left,rect.top,rect.Width(),rect.Height(),PATCOPY);
	pDC->SelectObject(poldBrush);
	pDC->Rectangle(19,19,501,501);
	oninit();
}

/////////////////////////////////////////////////////////////////////////////
// CBEANSView printing

BOOL CBEANSView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CBEANSView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CBEANSView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CBEANSView diagnostics

#ifdef _DEBUG
void CBEANSView::AssertValid() const
{
	CView::AssertValid();
}

void CBEANSView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBEANSDoc* CBEANSView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBEANSDoc)));
	return (CBEANSDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBEANSView message handlers

void CBEANSView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
		CDC *pDC=GetDC();
	CString soure;
	if (Beans[0].len==2) SetTimer(1,370,NULL);
	if (Beans[0].len==3) SetTimer(1,270,NULL);
	if (Beans[0].len==6) SetTimer(1,200,NULL);
	if (Beans[0].len==9) SetTimer(1,100,NULL);
	soure.Format("��õ��ˣ�%d!",(Beans[0].len-3)*10);
    //ײ���ж�
	if (Beans[0].x*20<=37||Beans[0].y*20<=37||Beans[0].x*20>=462||Beans[0].y*20>=462)
	{
		KillTimer(1);
		AfxMessageBox(soure);
	}

	//
	if (Beans[0].len>3)
		for (int sn=Beans[0].len-1;sn>0;sn--)
		{
			if(Beans[0].x*20==Beans[sn].x*20&&Beans[0].y==Beans[sn].y*20)
			{
				KillTimer(1);
				AfxMessageBox(soure);
			}
		}
		pDC->SelectStockObject(WHITE_PEN);
		pDC->Rectangle((Beans[Beans[0].len-1].x)*20,(Beans[Beans[0].len-1].y)*20,(Beans[Beans[0].len-1].x+1)*20,(Beans[Beans[0].len-1].y+1)*20);
		for (int i=Beans[0].len-1;i>0;i--)
		{
			Beans[i].x=Beans[i-1].x;
			Beans[i].y=Beans[i-1].y;
		}

		//���߷���
		if (Beans[0].direct==1) Beans[0].y--;
		if (Beans[0].direct==2) Beans[0].y++;
		if (Beans[0].direct==3) Beans[0].x--;
		if (Beans[0].direct==4) Beans[0].x++;
		pDC->SelectStockObject(BLACK_PEN);
		CBrush DrawBrush=(RGB(100,100,100));
		CBrush * Drawbrush=pDC->SelectObject(&DrawBrush);
		pDC->Ellipse(Beans[0].x*20,Beans[0].y*20,(Beans[0].x+1)*20,(Beans[0].y+1)*20);
		pDC->SelectObject(DrawBrush);

		//�жϳԶ���������ײ���ͳ�
		if (Beans[0].x*20==Food.x*20&&Beans[0].y*20==Food.y*20)
		{
			Beans[0].len;
			Food.isfood=1;
			Beans[Beans[0].len-1].x=Beans[Beans[0].len-2].x;
			Beans[Beans[0].len-1].y=Beans[Beans[0].len-2].y;
		}

		//������ӱ��Ծ�����
		if (Food.isfood==1)
		{
			srand((unsigned)time(NULL));
			do
			{
				for(int isfo=Beans[0].len-1;isfo>=0;isfo--)
					if(Beans[0].x*20==Beans[isfo].x*20&&Beans[0].y*20==Beans[isfo].y*20)
					{
						Food.x=rand()%25;
						Food.y=rand()%25;
					}
			}
			while (Food.x*20<70||Food.y*20<70||Food.x*20>430||Food.y*20>430);
			pDC->Ellipse(Food.x*20,Food.y*20,(Food.x+1)*20,(Food.y+1)*20);
			Food.isfood=0;
		}
	
	CView::OnTimer(nIDEvent);
}

void CBEANSView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnLButtonDown(nFlags, point);
}

void CBEANSView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CString str;
	str.Format("%d,%d",point.x,point.y);
	AfxMessageBox(str);
	CView::OnRButtonDown(nFlags, point);

}

void CBEANSView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CView::OnPaint() for painting messages
}

void CBEANSView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();

	Beans[0].x=10;
	Beans[0].y=10;
	Beans[0].direct=1;
	Beans[0].len=1;
	Food.isfood=1;
	// TODO: Add your specialized code here and/or call the base class
	
}

void CBEANSView::oninit()
{
    CDC *pDC=GetDC();
    int r=150;
	CBrush DrawBrush=(RGB(150,100,100));
	CBrush *Drawbrush=pDC->SelectObject(&DrawBrush);
	for(int i=0;i<=Beans[0].len-1;i++)
		pDC->Pie(Beans[i].x*20,Beans[i].y*20,(Beans[i].x+1)*20,(Beans[i].y+1)*20,Beans[i].x*20,Beans[i].y*20,(Beans[i].x+1)*20,(Beans[i].y+1)*20);
	    pDC->SelectObject(DrawBrush);
}

void CBEANSView::OnStart() 
{
	// TODO: Add your command handler code here
	SetTimer(1,800,NULL);
	AfxMessageBox("3���ʼ��Ϸ��");
}

void CBEANSView::OnPause() 
{
	// TODO: Add your command handler code here
		KillTimer(1);
	AfxMessageBox("��Ϸ��ͣ��������");
}

void CBEANSView::OnExit() 
{
	// TODO: Add your command handler code here
		AfxMessageBox("��Ϸ������������");
}

void CBEANSView::OnContinue() 
{
	// TODO: Add your command handler code here
		SetTimer(1,10,NULL);
}


void CBEANSView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	switch(nChar)
	{
	case VK_UP:if(Beans[0].direct!=2) Beans[0].direct=1;break;
	case VK_DOWN:if(Beans[0].direct!=1) Beans[0].direct=2;break;
	case VK_LEFT:if(Beans[0].direct!=4) Beans[0].direct=3;break;
	case VK_RIGHT:if(Beans[0].direct!=3) Beans[0].direct=4;break;
	}

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
	
}
