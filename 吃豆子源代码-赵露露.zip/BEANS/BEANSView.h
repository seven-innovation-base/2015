// BEANSView.h : interface of the CBEANSView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BEANSVIEW_H__23CAC8F1_2D82_49D7_9420_4B7C5B2774A0__INCLUDED_)
#define AFX_BEANSVIEW_H__23CAC8F1_2D82_49D7_9420_4B7C5B2774A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CBEANSView : public CView
{
protected: // create from serialization only
	CBEANSView();
	DECLARE_DYNCREATE(CBEANSView)

// Attributes
public:
	CBEANSDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBEANSView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void oninit();
	virtual ~CBEANSView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBEANSView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnStart();
	afx_msg void OnPause();
	afx_msg void OnExit();
	afx_msg void OnContinue();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in BEANSView.cpp
inline CBEANSDoc* CBEANSView::GetDocument()
   { return (CBEANSDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BEANSVIEW_H__23CAC8F1_2D82_49D7_9420_4B7C5B2774A0__INCLUDED_)
